import{e as a}from"../chunks/entry.N1xM51Zv.js";export{a as start};
