import{b as o,a as e}from"../chunks/disclose-version.B1zM0Eo-.js";import{n}from"../chunks/runtime.BjDaq2n6.js";function m(t){n();var a=o("DASHBOARD");e(t,a)}export{m as component};
